﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.1.3),
    on July 15, 2020, at 17:30
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.1.3'
expName = 'untitled'  # from the Builder filename that created this script
expInfo = {'Age': '', 'Gender': ['Female', 'Male', 'Other'], 'UIN': '', 'Left/Right Handed?': ['Right', 'Left']}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['UIN'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\yamauchiadmin\\Desktop\\Flanker Simple Mouse - Copy\\Flanker_Mouse_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[1,1,1], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Initialize"
InitializeClock = core.Clock()
from pylsl import StreamInfo, StreamOutlet

import os, sys, subprocess, winpexpect, time
sys.path.append('./lib/')

# Run GSR Send to LSL
# GSR = subprocess.Popen(['python.exe', 'Serial2LSL.py'])


# Run Gazepoint Control (for Calibration) --
# Gazepoint Control must be open in the background while the experiment is running

os.system("TASKKILL /F /IM Gazepoint.exe")
Gazepoint_Control = subprocess.Popen("C:/Program Files (x86)/Gazepoint/Gazepoint/bin64/Gazepoint.exe")

# Run Unicorn LSL -- Sending Unicorn Data to LSL
UnicornLSL = subprocess.Popen("./lib/UnicornLSL/UnicornLSL.exe")

# Run OpenBCI Send Data to LSL
OpenBCI = subprocess.Popen(['python.exe',"./lib/OpenBCILSL/OpenBCILSL.py"])

# Send Mindwave data to LSL -- Remember to install Mindwave LSL using: pip install mindwavelsl
#from mindwavelsl import MindwaveLSL
#mwlsl = MindwaveLSL('localhost', 13854)
#mwlsl.setup()
#mwlsl.run()

# Set LSL_LOCAL_CLOCK for MUSE and Send Muse Data to LSL
# Download and Install Bluemuse from: https://github.com/kowalej/BlueMuse/releases/download/v2.1/BlueMuse_2.1.0.0.zip
#   1. Navigate to the unzipped app folder and run the .\InstallBlueMuse.ps1 PowerShell command (right click and choose Run with PowerShell or execute from terminal directly):
#   2. Follow the prompts - the script should automatically install the security certificate, all dependencies, and the BlueMuse app.
# Install Muselsl using: pip install muselsl
# Reference: https://github.com/kowalej/BlueMuse

subprocess.check_output("start bluemuse://setting?key=primary_timestamp_format!value=LSL_LOCAL_CLOCK_NATIVE", shell=True)
subprocess.check_output("start bluemuse://start?streamfirst=true", shell=True)


# Run Kinect Body Basics LSL -- Sending kinect Body Basics Data to LSL
# Remember to Download and Install Microsoft Kinect for Windows SDK 2.0 from:
# https://www.microsoft.com/en-us/download/details.aspx?id=44561
# Restart your PC after installing Kinect SDK
Kinect_BodyBasics_LSL = subprocess.Popen("./lib/Kinect-BodyBasics-LSL/BodyBasicsLSL.exe")




# stim_type
info_stim_type= StreamInfo(name='Psychopy_stim_type', type='Markers', channel_count=1,
                  channel_format='string', source_id='Marker123')
outlet_stim_type = StreamOutlet(info_stim_type)


#clicking on a left/right button
info_mouseClick= StreamInfo(name='Psychopy_mouseClick', type='Markers', channel_count=1,
                  channel_format='string', source_id='mouseclick123')
outlet_mouseClick = StreamOutlet(info_mouseClick)

#mouse position & time: mouse.x, mouse.y, mouse.time
info_mousePos= StreamInfo(name='Psychopy_mousePos', type='Markers', channel_count=3,
                  channel_format='float32', source_id='mousePos123')
outlet_mousePos = StreamOutlet(info_mousePos)


currentTime = expInfo['date']
subjectID = expInfo['UIN']
Labrecorder = '.\lib\LabRecorder\LabRecorderCLI.exe'
Dataset='.\stream'

# Open LabRecorder


pause_time_counter = 0
text_begin = visual.TextStim(win=win, name='text_begin',
    text='Press "Space" to Begin',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color=[-1,-1,-1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_begin = keyboard.Keyboard()

# Initialize components for Routine "Record_Start"
Record_StartClock = core.Clock()
key_record = keyboard.Keyboard()
text_record = visual.TextStim(win=win, name='text_record',
    text='LabRecorder Started Saving the LSL Streams...\n\nPlease press "Space" to continue.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "Instruction_For_Mouse"
Instruction_For_MouseClock = core.Clock()
key_instruct = keyboard.Keyboard()
text_instruct = visual.TextStim(win=win, name='text_instruct',
    text='Click on the Arrows on "Top Left" or "Top Right" of the Screen. ',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "Inter_Stimulus_Wait"
Inter_Stimulus_WaitClock = core.Clock()
blank_text = visual.TextStim(win=win, name='blank_text',
    text=None,
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Fixation"
FixationClock = core.Clock()
fixation_sign = visual.TextStim(win=win, name='fixation_sign',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Stimulus_Presentation"
Stimulus_PresentationClock = core.Clock()
Left_resp = visual.Rect(
    win=win, name='Left_resp',
    width=(0.25, 0.2)[0], height=(0.25, 0.2)[1],
    ori=0, pos=(-0.85, 0.825),
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor='grey', fillColorSpace='rgb',
    opacity=1, depth=0.0, interpolate=True)
Right_resp = visual.Rect(
    win=win, name='Right_resp',
    width=(0.25, 0.2)[0], height=(0.25, 0.2)[1],
    ori=0, pos=(0.85, 0.825),
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor='grey', fillColorSpace='rgb',
    opacity=1, depth=-1.0, interpolate=True)
Left_arr = visual.TextStim(win=win, name='Left_arr',
    text='<-',
    font='Arial',
    pos=(-0.85, 0.85), height=0.3, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
Right_arr = visual.TextStim(win=win, name='Right_arr',
    text='->',
    font='Arial',
    pos=(0.85, 0.85), height=0.3, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
Stimulus = visual.TextStim(win=win, name='Stimulus',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);
Error = visual.TextStim(win=win, name='Error',
    text='Please Click on Left or Right Box',
    font='Arial',
    pos=(0, 0.5), height=0.1, wrapWidth=None, ori=0, 
    color=[-1,-1,-1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
mouse = event.Mouse(win=win)
x, y = [None, None]
mouse.mouseClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Initialize"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_begin.keys = []
key_resp_begin.rt = []
_key_resp_begin_allKeys = []
# keep track of which components have finished
InitializeComponents = [text_begin, key_resp_begin]
for thisComponent in InitializeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
InitializeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Initialize"-------
while continueRoutine:
    # get current time
    t = InitializeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=InitializeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_begin* updates
    if text_begin.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_begin.frameNStart = frameN  # exact frame index
        text_begin.tStart = t  # local t and not account for scr refresh
        text_begin.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_begin, 'tStartRefresh')  # time at next scr refresh
        text_begin.setAutoDraw(True)
    
    # *key_resp_begin* updates
    waitOnFlip = False
    if key_resp_begin.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_begin.frameNStart = frameN  # exact frame index
        key_resp_begin.tStart = t  # local t and not account for scr refresh
        key_resp_begin.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_begin, 'tStartRefresh')  # time at next scr refresh
        key_resp_begin.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_begin.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_begin.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_begin.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_begin.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_begin_allKeys.extend(theseKeys)
        if len(_key_resp_begin_allKeys):
            key_resp_begin.keys = _key_resp_begin_allKeys[-1].name  # just the last key pressed
            key_resp_begin.rt = _key_resp_begin_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InitializeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Initialize"-------
for thisComponent in InitializeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
win.winHandle.minimize()
thisExp.addData('text_begin.started', text_begin.tStartRefresh)
thisExp.addData('text_begin.stopped', text_begin.tStopRefresh)
# check responses
if key_resp_begin.keys in ['', [], None]:  # No response was made
    key_resp_begin.keys = None
thisExp.addData('key_resp_begin.keys',key_resp_begin.keys)
if key_resp_begin.keys != None:  # we had a response
    thisExp.addData('key_resp_begin.rt', key_resp_begin.rt)
thisExp.addData('key_resp_begin.started', key_resp_begin.tStartRefresh)
thisExp.addData('key_resp_begin.stopped', key_resp_begin.tStopRefresh)
thisExp.nextEntry()
# the Routine "Initialize" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Record_Start"-------
continueRoutine = True
# update component parameters for each repeat
key_record.keys = []
key_record.rt = []
_key_record_allKeys = []
# keep track of which components have finished
Record_StartComponents = [key_record, text_record]
for thisComponent in Record_StartComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Record_StartClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Record_Start"-------
while continueRoutine:
    # get current time
    t = Record_StartClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Record_StartClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *key_record* updates
    waitOnFlip = False
    if key_record.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_record.frameNStart = frameN  # exact frame index
        key_record.tStart = t  # local t and not account for scr refresh
        key_record.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_record, 'tStartRefresh')  # time at next scr refresh
        key_record.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_record.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_record.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_record.status == STARTED and not waitOnFlip:
        theseKeys = key_record.getKeys(keyList=['space'], waitRelease=False)
        _key_record_allKeys.extend(theseKeys)
        if len(_key_record_allKeys):
            key_record.keys = _key_record_allKeys[-1].name  # just the last key pressed
            key_record.rt = _key_record_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *text_record* updates
    if text_record.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_record.frameNStart = frameN  # exact frame index
        text_record.tStart = t  # local t and not account for scr refresh
        text_record.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_record, 'tStartRefresh')  # time at next scr refresh
        text_record.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Record_StartComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Record_Start"-------
for thisComponent in Record_StartComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_record.keys in ['', [], None]:  # No response was made
    key_record.keys = None
thisExp.addData('key_record.keys',key_record.keys)
if key_record.keys != None:  # we had a response
    thisExp.addData('key_record.rt', key_record.rt)
thisExp.addData('key_record.started', key_record.tStartRefresh)
thisExp.addData('key_record.stopped', key_record.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('text_record.started', text_record.tStartRefresh)
thisExp.addData('text_record.stopped', text_record.tStopRefresh)
if Gazepoint_Control.poll() is not None:
    
    Gazepoint_Control = subprocess.Popen("C:/Program Files (x86)/Gazepoint/Gazepoint/bin64/Gazepoint.exe")

GazepointLSL = subprocess.Popen(['python.exe', '.\lib\Gazepoint(Eyetracking+Biometrics)-LSL\LSLGazepoint.py'])

child =  winpexpect.winspawn('%s %s\%s_%s.xdf \'name="Keyboard"\'' % (Labrecorder,Dataset,currentTime,subjectID))

# the Routine "Record_Start" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instruction_For_Mouse"-------
continueRoutine = True
# update component parameters for each repeat
key_instruct.keys = []
key_instruct.rt = []
_key_instruct_allKeys = []
# keep track of which components have finished
Instruction_For_MouseComponents = [key_instruct, text_instruct]
for thisComponent in Instruction_For_MouseComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instruction_For_MouseClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instruction_For_Mouse"-------
while continueRoutine:
    # get current time
    t = Instruction_For_MouseClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instruction_For_MouseClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *key_instruct* updates
    waitOnFlip = False
    if key_instruct.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_instruct.frameNStart = frameN  # exact frame index
        key_instruct.tStart = t  # local t and not account for scr refresh
        key_instruct.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_instruct, 'tStartRefresh')  # time at next scr refresh
        key_instruct.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_instruct.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_instruct.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_instruct.status == STARTED and not waitOnFlip:
        theseKeys = key_instruct.getKeys(keyList=['space'], waitRelease=False)
        _key_instruct_allKeys.extend(theseKeys)
        if len(_key_instruct_allKeys):
            key_instruct.keys = _key_instruct_allKeys[-1].name  # just the last key pressed
            key_instruct.rt = _key_instruct_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *text_instruct* updates
    if text_instruct.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_instruct.frameNStart = frameN  # exact frame index
        text_instruct.tStart = t  # local t and not account for scr refresh
        text_instruct.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_instruct, 'tStartRefresh')  # time at next scr refresh
        text_instruct.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instruction_For_MouseComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instruction_For_Mouse"-------
for thisComponent in Instruction_For_MouseComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_instruct.keys in ['', [], None]:  # No response was made
    key_instruct.keys = None
thisExp.addData('key_instruct.keys',key_instruct.keys)
if key_instruct.keys != None:  # we had a response
    thisExp.addData('key_instruct.rt', key_instruct.rt)
thisExp.addData('key_instruct.started', key_instruct.tStartRefresh)
thisExp.addData('key_instruct.stopped', key_instruct.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('text_instruct.started', text_instruct.tStartRefresh)
thisExp.addData('text_instruct.stopped', text_instruct.tStopRefresh)
# the Routine "Instruction_For_Mouse" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Trials_Loop = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Stimuli\\stimuliFile.xlsx'),
    seed=None, name='Trials_Loop')
thisExp.addLoop(Trials_Loop)  # add the loop to the experiment
thisTrials_Loop = Trials_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrials_Loop.rgb)
if thisTrials_Loop != None:
    for paramName in thisTrials_Loop:
        exec('{} = thisTrials_Loop[paramName]'.format(paramName))

for thisTrials_Loop in Trials_Loop:
    currentLoop = Trials_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_Loop.rgb)
    if thisTrials_Loop != None:
        for paramName in thisTrials_Loop:
            exec('{} = thisTrials_Loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Inter_Stimulus_Wait"-------
    continueRoutine = True
    routineTimer.add(1.200000)
    # update component parameters for each repeat
    # keep track of which components have finished
    Inter_Stimulus_WaitComponents = [blank_text]
    for thisComponent in Inter_Stimulus_WaitComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Inter_Stimulus_WaitClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Inter_Stimulus_Wait"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = Inter_Stimulus_WaitClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Inter_Stimulus_WaitClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank_text* updates
        if blank_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            blank_text.frameNStart = frameN  # exact frame index
            blank_text.tStart = t  # local t and not account for scr refresh
            blank_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(blank_text, 'tStartRefresh')  # time at next scr refresh
            blank_text.setAutoDraw(True)
        if blank_text.status == STARTED:
            # is it time to stop? (based on local clock)
            if tThisFlip > 1.2-frameTolerance:
                # keep track of stop time/frame for later
                blank_text.tStop = t  # not accounting for scr refresh
                blank_text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(blank_text, 'tStopRefresh')  # time at next scr refresh
                blank_text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Inter_Stimulus_WaitComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Inter_Stimulus_Wait"-------
    for thisComponent in Inter_Stimulus_WaitComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Trials_Loop.addData('blank_text.started', blank_text.tStartRefresh)
    Trials_Loop.addData('blank_text.stopped', blank_text.tStopRefresh)
    
    # ------Prepare to start Routine "Fixation"-------
    continueRoutine = True
    routineTimer.add(0.500000)
    # update component parameters for each repeat
    mouse.setPos([0,-0.8])
    # keep track of which components have finished
    FixationComponents = [fixation_sign]
    for thisComponent in FixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    FixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Fixation"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = FixationClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=FixationClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *fixation_sign* updates
        if fixation_sign.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            fixation_sign.frameNStart = frameN  # exact frame index
            fixation_sign.tStart = t  # local t and not account for scr refresh
            fixation_sign.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fixation_sign, 'tStartRefresh')  # time at next scr refresh
            fixation_sign.setAutoDraw(True)
        if fixation_sign.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > fixation_sign.tStartRefresh + 0.5-frameTolerance:
                # keep track of stop time/frame for later
                fixation_sign.tStop = t  # not accounting for scr refresh
                fixation_sign.frameNStop = frameN  # exact frame index
                win.timeOnFlip(fixation_sign, 'tStopRefresh')  # time at next scr refresh
                fixation_sign.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in FixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Fixation"-------
    for thisComponent in FixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Trials_Loop.addData('fixation_sign.started', fixation_sign.tStartRefresh)
    Trials_Loop.addData('fixation_sign.stopped', fixation_sign.tStopRefresh)
    
    # ------Prepare to start Routine "Stimulus_Presentation"-------
    continueRoutine = True
    # update component parameters for each repeat
    Stimulus.setText(stim)
    # setup some python lists for storing info about the mouse
    mouse.x = []
    mouse.y = []
    mouse.leftButton = []
    mouse.midButton = []
    mouse.rightButton = []
    mouse.time = []
    mouse.clicked_name = []
    gotValidClick = False  # until a click is received
    mouse.setPos([0,-0.8])
    outlet_stim_type.push_chunk(stim_type)
    # keep track of which components have finished
    Stimulus_PresentationComponents = [Left_resp, Right_resp, Left_arr, Right_arr, Stimulus, Error, mouse]
    for thisComponent in Stimulus_PresentationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Stimulus_PresentationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Stimulus_Presentation"-------
    while continueRoutine:
        # get current time
        t = Stimulus_PresentationClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Stimulus_PresentationClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Left_resp* updates
        if Left_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Left_resp.frameNStart = frameN  # exact frame index
            Left_resp.tStart = t  # local t and not account for scr refresh
            Left_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Left_resp, 'tStartRefresh')  # time at next scr refresh
            Left_resp.setAutoDraw(True)
        
        # *Right_resp* updates
        if Right_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Right_resp.frameNStart = frameN  # exact frame index
            Right_resp.tStart = t  # local t and not account for scr refresh
            Right_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Right_resp, 'tStartRefresh')  # time at next scr refresh
            Right_resp.setAutoDraw(True)
        
        # *Left_arr* updates
        if Left_arr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Left_arr.frameNStart = frameN  # exact frame index
            Left_arr.tStart = t  # local t and not account for scr refresh
            Left_arr.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Left_arr, 'tStartRefresh')  # time at next scr refresh
            Left_arr.setAutoDraw(True)
        
        # *Right_arr* updates
        if Right_arr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Right_arr.frameNStart = frameN  # exact frame index
            Right_arr.tStart = t  # local t and not account for scr refresh
            Right_arr.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Right_arr, 'tStartRefresh')  # time at next scr refresh
            Right_arr.setAutoDraw(True)
        
        # *Stimulus* updates
        if Stimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Stimulus.frameNStart = frameN  # exact frame index
            Stimulus.tStart = t  # local t and not account for scr refresh
            Stimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Stimulus, 'tStartRefresh')  # time at next scr refresh
            Stimulus.setAutoDraw(True)
        if Stimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Stimulus.tStartRefresh + 0.2-frameTolerance:
                # keep track of stop time/frame for later
                Stimulus.tStop = t  # not accounting for scr refresh
                Stimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Stimulus, 'tStopRefresh')  # time at next scr refresh
                Stimulus.setAutoDraw(False)
        
        # *Error* updates
        if Error.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
            # keep track of start time/frame for later
            Error.frameNStart = frameN  # exact frame index
            Error.tStart = t  # local t and not account for scr refresh
            Error.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Error, 'tStartRefresh')  # time at next scr refresh
            Error.setAutoDraw(True)
        # *mouse* updates
        if mouse.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse.frameNStart = frameN  # exact frame index
            mouse.tStart = t  # local t and not account for scr refresh
            mouse.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse, 'tStartRefresh')  # time at next scr refresh
            mouse.status = STARTED
            mouse.mouseClock.reset()
            prevButtonState = mouse.getPressed()  # if button is down already this ISN'T a new click
        if mouse.status == STARTED:  # only update if started and not finished!
            x, y = mouse.getPos()
            mouse.x.append(x)
            mouse.y.append(y)
            buttons = mouse.getPressed()
            mouse.leftButton.append(buttons[0])
            mouse.midButton.append(buttons[1])
            mouse.rightButton.append(buttons[2])
            mouse.time.append(mouse.mouseClock.getTime())
            buttons = mouse.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    for obj in [Left_resp, Right_resp]:
                        if obj.contains(mouse):
                            gotValidClick = True
                            mouse.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        T=mouse.time[-1]
        X=mouse.x[-1]
        Y=mouse.y[-1]
        
        outlet_mousePos.push_chunk([X, Y, T])
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Stimulus_PresentationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Stimulus_Presentation"-------
    for thisComponent in Stimulus_PresentationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Trials_Loop.addData('Left_resp.started', Left_resp.tStartRefresh)
    Trials_Loop.addData('Left_resp.stopped', Left_resp.tStopRefresh)
    Trials_Loop.addData('Right_resp.started', Right_resp.tStartRefresh)
    Trials_Loop.addData('Right_resp.stopped', Right_resp.tStopRefresh)
    Trials_Loop.addData('Left_arr.started', Left_arr.tStartRefresh)
    Trials_Loop.addData('Left_arr.stopped', Left_arr.tStopRefresh)
    Trials_Loop.addData('Right_arr.started', Right_arr.tStartRefresh)
    Trials_Loop.addData('Right_arr.stopped', Right_arr.tStopRefresh)
    Trials_Loop.addData('Stimulus.started', Stimulus.tStartRefresh)
    Trials_Loop.addData('Stimulus.stopped', Stimulus.tStopRefresh)
    Trials_Loop.addData('Error.started', Error.tStartRefresh)
    Trials_Loop.addData('Error.stopped', Error.tStopRefresh)
    # store data for Trials_Loop (TrialHandler)
    Trials_Loop.addData('mouse.x', mouse.x)
    Trials_Loop.addData('mouse.y', mouse.y)
    Trials_Loop.addData('mouse.leftButton', mouse.leftButton)
    Trials_Loop.addData('mouse.midButton', mouse.midButton)
    Trials_Loop.addData('mouse.rightButton', mouse.rightButton)
    Trials_Loop.addData('mouse.time', mouse.time)
    Trials_Loop.addData('mouse.clicked_name', mouse.clicked_name)
    Trials_Loop.addData('mouse.started', mouse.tStart)
    Trials_Loop.addData('mouse.stopped', mouse.tStop)
    outlet_mouseClick.push_chunk(mouse.clicked_name)
    
    
    # the Routine "Stimulus_Presentation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'Trials_Loop'

child.sendline('\r')
UnicornLSL.kill()
Kinect_BodyBasics_LSL.kill()

#GSR.kill()
subprocess.check_output("start bluemuse://shutdown", shell=True)
GazepointLSL.kill()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
